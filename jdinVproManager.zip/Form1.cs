﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


// Cognex
using Cognex.VisionPro;
using Cognex.VisionPro.ImageFile;
using Cognex.VisionPro.ImageProcessing;
using Cognex.VisionPro.QuickBuild;
using Cognex.VisionPro.ToolGroup;


namespace $safeprojectname$
{
    public partial class Form1 : Form
    {
        CogJobManager jobManager;
        List<CogJob> job = new List<CogJob>();
        List<CogJobIndependent> jobIndependent = new List<CogJobIndependent>();

        string jobFilePath;

        public Form1()
        {
            InitializeComponent();

            btnLoadJob_Click();
        }



        private void btnLoadJob_Click()
        {
            // Open a file dialog to select the VPP file
            try
            {
                using (OpenFileDialog openFileDialog = new OpenFileDialog())
                {
                    openFileDialog.Filter = "VisionPro Job Files (*.vpp)|*.vpp";
                    openFileDialog.Title = "Select a VisionPro Job File";
                    if (openFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        jobFilePath = openFileDialog.FileName;
                        LoadVisionProJob(jobFilePath);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading job file: " + ex.Message, "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                
            }
        }

        private void LoadVisionProJob(string filePath)
        {
            // job = (CogJob)CogSerializer.LoadObjectFromFile(filePath);

            // job.Run();

            int count = 0;
            try
            {
                // "QuickBuilder응용 프로그램" 으로 저장 된 Job으로 저장한 것을 읽어온다.
                // 작업 JOb 파일은 QuickBuilder에서 하단에 "CongJob1"으로 표시되는 것을 말한다.
                jobManager = (CogJobManager)CogSerializer.LoadObjectFromFile(filePath);


                if (jobManager is CogJobManager)
                {
                    // MessageBox.Show("잡파일 로드 됨");
                    count = jobManager.JobCount;

                    for (int i = 0; i < count; i++)
                    {
                        job.Add(jobManager.Job(i));
                        jobIndependent.Add(job[i].OwnedIndependent);

                        MessageBox.Show("잡파일 로드 됨 : " + job[i].Name);  // "CogJob1"
                    }

                    jobManager.UserQueueFlush();
                    jobManager.FailureQueueFlush();

                    // 여기는 어떤 내용인지 확인해 불 것 : perplexity 참조
                    // 사용자 결과 큐, 실패 큐, 이미지 큐, 실시간 큐를 초기화하여 이전 데이터가 남지 않도록 합니다.
                    for (int i = 0; i < jobManager.JobCount; i++)
                    {
                        job[i].ImageQueueFlush();
                        jobIndependent[i].RealTimeQueueFlush();
                    }
                }
                else
                {
                    throw new Exception("로드된 객체가 QuickBuilder Job 아닙니다.");
                }

                
                jobManager.Run();   // 오류 없음

                // 결과 대기 및 수집
                ICogRecord record = null;
                while (record == null)
                {
                    record = jobManager.UserResult();
                }
                // Run()으로 모든 Job을 실행하고, UserResult()로 결과가 나올 때까지 대기합니다.
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading job file: " + ex.Message, "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
 }
