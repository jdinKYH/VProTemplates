﻿using Cognex.VisionPro;
using Cognex.VisionPro.QuickBuild;
using Cognex.VisionPro.ToolBlock;
using Cognex.VisionPro.ToolGroup;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $safeprojectname$
{
    public partial class MainForm : Form
    {
        private CogJobManager _jobManager;
        private object _targetSubject; // ToolBlock 혹은 ToolGroup 등 유연한 바인딩용
        private string _currentFilePath = string.Empty;

        // 유연한 에디터 컨트롤 (ToolGroupEditV2 또는 ToolBlockEditV2 선택 가능)
        private CogToolGroupEditV2 _toolGroupEditor; // QuickBuild Job 내부는 보통 ToolGroup 구조

        private Button btnLoad;
        private Button btnSave;
        private Panel panelEditorContainer;


        public MainForm()
        {
            InitializeComponentCustom();
        }


        /// <summary>
        /// UI 컨트롤 초기화 및 배치
        /// </summary>
        private void InitializeComponentCustom()
        {
            this.Text = "VisionPro Job Editor (QuickBuild 독립형 - Group 대응)";
            this.Width = 1200;
            this.Height = 800;
            this.StartPosition = FormStartPosition.CenterScreen;

            Panel topPanel = new Panel() { Dock = DockStyle.Top, Height = 50 };

            btnLoad = new Button() { Text = "Job(ToolGroup) 파일 로드", Left = 12, Top = 10, Width = 180, Height = 30 };
            btnLoad.Click += BtnLoad_Click;

            btnSave = new Button() { Text = "변경사항 저장", Left = 200, Top = 10, Width = 120, Height = 30 };
            btnSave.Enabled = false;
            btnSave.Click += BtnSave_Click;

            topPanel.Controls.Add(btnLoad);
            topPanel.Controls.Add(btnSave);

            panelEditorContainer = new Panel() { Dock = DockStyle.Fill };
            this.Controls.Add(panelEditorContainer);
            this.Controls.Add(topPanel);

            // QuickBuild Job 내부 구조에 최적화된 CogToolGroupEditV2 사용
            _toolGroupEditor = new CogToolGroupEditV2();
            _toolGroupEditor.Dock = DockStyle.Fill;
            panelEditorContainer.Controls.Add(_toolGroupEditor);

            this.FormClosing += MainForm_FormClosing;
        }

        /// <summary>
        /// [로드 버튼] .vpp 파일 선택 및 로드
        /// </summary>
        private void BtnLoad_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "VisionPro Job Files (*.vpp)|*.vpp|All Files (*.*)|*.*";
                openFileDialog.Title = "편집할 Job(.vpp) 파일 선택";
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    _currentFilePath = openFileDialog.FileName;
                    LoadJobFile(_currentFilePath);
                }
            }
        }


        /// <summary>
        /// .vpp 파일 역직렬화 및 툴 추출
        /// toolBlock01.vpp 파일을 예시로, CogJobManager 또는 CogToolBlock 객체를 로드하고, 에디터에 바인딩
        /// </summary>
        private void LoadJobFile(string filePath)
        {
            // =================================================================================================
            // 261026@jdin "ToolGroup 용" vpp 파일을 로드한다. 
            // =================================================================================================
            try
            {
                if (_toolGroupEditor != null)
                {
                    _toolGroupEditor.Subject = null;
                }

                object loadedObject = CogSerializer.LoadObjectFromFile(filePath);

                if (loadedObject is CogJobManager jobManager)
                {
                    _jobManager = jobManager;
                    if (_jobManager.JobCount > 0)
                    {
                        CogJob job = _jobManager.Job(0);

                        // 지적하신 대로 job.VisionTool은 ToolGroup 구조를 가짐
                        // 필요에 따라 CogToolGroup 또는 내부 CogToolBlock 추출
                        _targetSubject = job.VisionTool as CogToolGroup;

                        // 만약 내부의 특정 CogToolBlock을 직접 꺼내서 편집하고 싶다면 아래와 같이 탐색 가능
                        /*
                        if (_targetSubject is CogToolGroup toolGroup)
                        {
                            foreach (ICogTool tool in toolGroup.Tools)
                            {
                                if (tool is CogToolBlock block)
                                {
                                    // 원하는 블록을 찾아 바인딩 가능
                                }
                            }
                        }
                        */
                    }
                }
                else if (loadedObject is CogToolGroup toolGroupObj)
                {
                    _targetSubject = toolGroupObj;
                    _jobManager = null;
                }
                else if (loadedObject is CogToolBlock toolBlockObj)
                {
                    _targetSubject = toolBlockObj;
                    _jobManager = null;
                }

                // 에디터에 바인딩
                if (_targetSubject != null && _targetSubject is CogToolGroup targetGroup)
                {
                    _toolGroupEditor.Subject = targetGroup;
                    btnSave.Enabled = true;
                    MessageBox.Show($"파일 로드 성공 (ToolGroup 구조):\n{Path.GetFileName(filePath)}", "완료", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("불러온 파일에서 편집 가능한 ToolGroup 구조를 확인할 수 없습니다.", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    btnSave.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Job 파일 로드 중 오류 발생:\n{ex.Message}", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                btnSave.Enabled = false;
            }
        }

        /// <summary>
        /// [저장 버튼] 수정본을 원본 .vpp 파일로 덮어쓰기
        /// </summary>
        private void BtnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(_currentFilePath)) return;

            try
            {
                object targetToSave = _jobManager != null ? (object)_jobManager : _targetSubject;

                if (targetToSave != null)
                {
                    CogSerializer.SaveObjectToFile(
                        targetToSave,
                        _currentFilePath,
                        typeof(BinaryFormatter),    // 정상 동작
                        CogSerializationOptionsConstants.All
                    );

                    MessageBox.Show("Job 파일이 성공적으로 수정 및 저장되었습니다.", "저장 완료", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Job 파일 저장 중 오류 발생:\n{ex.Message}", "저장 실패", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// 자원 해제 (메모리 누수 방지)
        /// </summary>
        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (_toolGroupEditor != null)
                {
                    _toolGroupEditor.Subject = null;
                    _toolGroupEditor.Dispose();
                    _toolGroupEditor = null;
                }

                _jobManager = null;
                _targetSubject = null;
            }
            catch 
            {
                // 예외 무시, 종료 시 자원 해제 중 발생할 수 있는 오류는 무시
            }
        }
    }
}
